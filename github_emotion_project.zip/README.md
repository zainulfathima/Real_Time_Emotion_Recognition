# Real-Time Emotion Recognition (CNN + OpenCV)

This project performs real-time facial emotion recognition using a CNN model trained on the FER2013 dataset.

## 📁 Project Structure
```
.
├── src/
│   ├── train_emotion_recognition.py
│   ├── realtime_emotion_recognition.py
├── requirements.txt
├── LICENSE
└── README.md
```

## 🚀 Quick Start

### 1. Install requirements
```
pip install -r requirements.txt
```

### 2. Add required files
Place these files in the project root:
- `fer2013.csv`
- `haarcascade_frontalface_default.xml`

### 3. Train the model
```
python src/train_emotion_recognition.py
```

### 4. Run real-time recognition
```
python src/realtime_emotion_recognition.py
```

## 📝 Notes
- The model trains on grayscale 48×48 images.
- This repo does not include the dataset due to size.

## 📄 License
This project is under the MIT License.
